export interface HobbyData {
  title: string;
  description: string;
}

export interface HobbyResponse {
  data: HobbyData;
}