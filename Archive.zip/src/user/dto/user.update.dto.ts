export class UpdateUserDto {
  readonly username: string;
  readonly email: string;
}