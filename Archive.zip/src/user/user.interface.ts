export interface UserData {
    username: string;
    email: string;
  }
  
  export interface UserResponse {
    user: UserData;
  }